# Auralis backend

Express/Mongoose API for Auralis authentication, user-owned conversations, Groq generation, usage analytics, and administration. For complete application architecture, frontend setup, deployment notes, API details, and test commands, see the [project README](../README.md).

## Quick start

1. Use Node.js 20.19+ or 22.12+ and start MongoDB.
2. If `.env` does not exist, copy `.env.example` to `.env`; configure `MONGO_URI`, a random `JWT_SECRET` of at least 32 characters, `GROQ_API_KEY`, and the frontend origin in `CLIENT_URLS`.
3. Configure SMTP if password reset email should be available.
4. Install and seed an administrator:

   ```powershell
   npm install
   ```

   Set `ADMIN_NAME`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD` in `.env`, then run:

   ```powershell
   npm run seed:admin
   ```

5. Start the API:

   ```powershell
   npm run dev
   ```

Usage timestamps and reports are UTC. Prompt text is excluded unless `RETAIN_USAGE_PROMPTS=true`. The Groq request timeout is configured with `GROQ_TIMEOUT_MS`.

## Test

```powershell
npm test
```
