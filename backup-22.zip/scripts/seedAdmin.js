import 'dotenv/config'
import bcrypt from 'bcryptjs'
import mongoose from 'mongoose'
import User from '../src/models/User.js'

const { ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD, MONGO_URI } = process.env
if (!MONGO_URI?.trim()) throw new Error('MONGO_URI is missing from ai-backend/.env.')
if (!ADMIN_EMAIL?.trim()) {
  throw new Error('ADMIN_EMAIL is missing from ai-backend/.env. Set it to promote an existing account or create a new administrator.')
}

const email = ADMIN_EMAIL.trim().toLowerCase()
if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
  throw new Error('ADMIN_EMAIL must be a valid email address.')
}

try {
  await mongoose.connect(MONGO_URI)
  let user = await User.findOne({ email })
  if (user) {
    user.role = 'ADMIN'
    await user.save()
    console.log(`Promoted existing account ${email} to ADMIN; password unchanged.`)
  } else {
    if (!ADMIN_NAME?.trim() || ADMIN_NAME.trim().length > 80) {
      throw new Error('No account exists for ADMIN_EMAIL. Set ADMIN_NAME (1-80 characters) to create a new administrator.')
    }
    if (!ADMIN_PASSWORD || ADMIN_PASSWORD.length < 10 || ADMIN_PASSWORD.length > 128) {
      throw new Error('No account exists for ADMIN_EMAIL. Set ADMIN_PASSWORD (10-128 characters) to create a new administrator.')
    }
    user = await User.create({
      name: ADMIN_NAME.trim(),
      email,
      password: await bcrypt.hash(ADMIN_PASSWORD, 12),
      role: 'ADMIN',
    })
    console.log(`Created administrator account ${email}.`)
  }
} catch (error) {
  if (error.name === 'MongoServerSelectionError' || error.name === 'MongooseServerSelectionError') {
    throw new Error('Could not connect to MongoDB. Check that MongoDB is running and MONGO_URI points to the intended database.')
  }
  throw error
} finally {
  if (mongoose.connection.readyState !== 0) await mongoose.disconnect()
}
